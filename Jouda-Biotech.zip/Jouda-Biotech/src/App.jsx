import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously } from 'firebase/auth';
import { getFirestore, collection, doc, addDoc, deleteDoc, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { Dna, Heart, Settings, Trash2, CheckCircle, PlayCircle, Award, FileText, Download, ChevronLeft, Monitor, Smartphone, Clock, BarChart3 } from 'lucide-react';

// إعدادات Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAezpyB6YhZgGrGwj9GY6--cDmjsNh-J1g",
  authDomain: "jouda-biotech.firebaseapp.com",
  projectId: "jouda-biotech",
  storageBucket: "jouda-biotech.firebasestorage.app",
  messagingSenderId: "718959958507",
  appId: "1:718959958507:web:b14a4d0d9c2207594721ae",
  measurementId: "G-EE7MVT3HPF"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// مكون عرض الاختبار (تعريفه قبل App لضمان العمل)
const ExamView = ({ lesson, questions, onFinish, onBack }) => {
  const [answers, setAnswers] = useState({});
  const [done, setDone] = useState(false);

  const calculate = () => {
    let c = 0;
    questions.forEach(q => { if(answers[q.id] === q.correct) c++; });
    const res = Math.round((c / questions.length) * 100);
    setDone(true);
    onFinish(res); 
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-left duration-500 text-right" dir="rtl">
      <button onClick={onBack} className="flex items-center gap-2 text-blue-600 font-bold mb-4"><ChevronLeft size={18}/> العودة</button>
      <div className="bg-blue-900 text-white p-6 rounded-[2rem] shadow-xl">
        <h3 className="font-black text-xl italic">اختبار {lesson}</h3>
        <p className="text-blue-200 text-xs mt-1">أجيبي على جميع الأسئلة لاعتماد النتيجة</p>
      </div>
      {questions.map((q, i) => (
        <div key={q.id} className="bg-white p-6 rounded-[2rem] border shadow-sm text-right">
          <p className="font-bold text-slate-800 mb-4 italic">س{i+1}: {q.question}</p>
          <div className="grid gap-2">
            {q.options.map((opt, idx) => (
              <button key={idx} onClick={() => !done && setAnswers({...answers, [q.id]: opt})}
                className={`p-4 rounded-xl text-right font-medium transition-all border 
                ${done ? (opt === q.correct ? 'bg-green-100 border-green-300' : answers[q.id] === opt ? 'bg-red-100' : 'opacity-50')
                : (answers[q.id] === opt ? 'bg-blue-600 text-white' : 'bg-slate-50 hover:bg-slate-100')}`}
                disabled={done}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      ))}
      {!done && (
        <button onClick={calculate} disabled={Object.keys(answers).length < questions.length}
          className="w-full bg-slate-900 text-white py-4 rounded-[2rem] font-black disabled:opacity-50"
        >
          اعتماد نتيجة {lesson}
        </button>
      )}
    </div>
  );
};

const App = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [pass, setPass] = useState('');
  const [videos, setVideos] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [pdfs, setPdfs] = useState([]);
  const [testLogs, setTestLogs] = useState([]);
  const [visitLogs, setVisitLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeLesson, setActiveLesson] = useState(null);

  const logVisit = async () => {
    const device = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) ? "جوال" : "كمبيوتر";
    try {
      await addDoc(collection(db, 'visits'), {
        timestamp: new Date().toLocaleString('ar-SA'),
        device: device,
        userAgent: navigator.userAgent.slice(0, 50)
      });
    } catch(e) { console.error(e); }
  };

  useEffect(() => {
    signInAnonymously(auth);
    logVisit(); 

    onSnapshot(collection(db, 'videos'), (s) => setVideos(s.docs.map(d => ({id: d.id, ...d.data()}))));
    onSnapshot(collection(db, 'pdfs'), (s) => setPdfs(s.docs.map(d => ({id: d.id, ...d.data()}))));
    onSnapshot(collection(db, 'quizzes'), (s) => setQuizzes(s.docs.map(d => ({id: d.id, ...d.data()}))));

    onSnapshot(query(collection(db, 'test_results'), orderBy('timestamp', 'desc'), limit(20)), (s) => 
      setTestLogs(s.docs.map(d => ({id: d.id, ...d.data()}))));
    onSnapshot(query(collection(db, 'visits'), orderBy('timestamp', 'desc'), limit(20)), (s) => 
      setVisitLogs(s.docs.map(d => ({id: d.id, ...d.data()}))));

    setLoading(false);
  }, []);

  const addSmartQuiz = async (e) => {
    e.preventDefault();
    const { lesson, rawData } = e.target.elements;
    const parts = rawData.value.split('|').map(p => p.trim());

    if (parts.length < 6) {
      alert("يرجى اتباع الصيغة: السؤال | خيار1 | خيار2 | خيار3 | خيار4 | رقم الإجابة");
      return;
    }

    const options = [parts[1], parts[2], parts[3], parts[4]];
    await addDoc(collection(db, 'quizzes'), { 
      lesson: lesson.value, 
      question: parts[0], 
      options: options, 
      correct: options[parseInt(parts[5]) - 1] 
    });
    e.target.reset();
  };

  const saveResult = async (lessonName, score) => {
    await addDoc(collection(db, 'test_results'), {
      lesson: lessonName,
      score: score,
      timestamp: new Date().toLocaleString('ar-SA')
    });
  };

  if (loading) return <div className="h-screen flex items-center justify-center font-bold text-emerald-800">جاري التحميل...</div>;

  return (
    <div className="min-h-screen p-6 max-w-5xl mx-auto space-y-10 pb-24 text-right" dir="rtl">
      <header className="flex justify-between items-center bg-white p-4 rounded-full shadow-sm border border-slate-100">
        <h1 className="text-xl font-black text-emerald-950 flex items-center gap-2"><Dna className="text-emerald-600"/> Jouda Biotech</h1>
        <div className="bg-emerald-500 text-white px-4 py-1.5 rounded-full font-bold text-sm">جود</div>
      </header>

      <section className="bg-[#044735] rounded-[3rem] p-12 text-center text-white shadow-2xl relative overflow-hidden">
        <h2 className="text-4xl md:text-7xl font-black mb-6">هاي سمارت جودي</h2>
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-6 py-2 rounded-full border border-white/20">
          <span className="font-bold text-lg">بالتوفيق</span>
          <Heart className="text-emerald-400 fill-emerald-400 animate-pulse" />
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="space-y-10">
          <div className="space-y-6">
            <h3 className="text-2xl font-black text-slate-800 border-r-4 border-emerald-500 pr-3">الشرح</h3>
            {videos.map(v => (
              <div key={v.id} className="bg-white rounded-[2rem] overflow-hidden shadow-lg border relative">
                <iframe className="w-full aspect-video" src={v.url} frameBorder="0" allowFullScreen></iframe>
                <div className="p-4 font-bold text-slate-700">{v.title}</div>
              </div>
            ))}
          </div>
          <div className="space-y-6">
            <h3 className="text-2xl font-black text-slate-800 border-r-4 border-amber-500 pr-3">الملخصات (PDF)</h3>
            {pdfs.map(p => (
              <a key={p.id} href={p.link} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between bg-white p-4 rounded-2xl shadow-sm border border-slate-100 hover:border-amber-400">
                <div className="flex items-center gap-3"><FileText className="text-amber-600"/><span className="font-bold">{p.title}</span></div>
                <Download size={18} className="text-slate-300"/>
              </a>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-2xl font-black text-slate-800 border-r-4 border-blue-500 pr-3">الاختبارات</h3>
          {activeLesson ? (
             <ExamView 
              lesson={activeLesson} 
              questions={quizzes.filter(q => q.lesson === activeLesson)} 
              onFinish={(score) => {saveResult(activeLesson, score); setActiveLesson(null);}} 
              onBack={() => setActiveLesson(null)}
             />
          ) : (
            <div className="grid gap-3">
              {[...new Set(quizzes.map(q => q.lesson))].map(lesson => (
                <button key={lesson} onClick={() => setActiveLesson(lesson)} className="bg-white p-6 rounded-[2rem] border hover:border-blue-500 text-right font-bold shadow-sm flex justify-between items-center group">
                  <span>{lesson}</span>
                  <PlayCircle className="text-blue-500 group-hover:scale-110 transition-transform"/>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <footer className="text-center pt-10">
        <button onClick={() => setShowLogin(true)} className="text-slate-200 hover:text-emerald-600 transition-colors"><Settings/></button>
        <p className="text-[10px] text-slate-400 font-medium mt-4 uppercase tracking-widest">تم الصنع بكل حب لجود ❤️</p>
      </footer>

      {isAdmin && (
        <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-xl z-50 flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white w-full max-w-4xl rounded-[3rem] shadow-2xl max-h-[90vh] overflow-y-auto flex flex-col p-8">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black text-emerald-900 flex items-center gap-2"><BarChart3/> لوحة المراقبة والإدارة</h2>
              <button onClick={() => setIsAdmin(false)} className="bg-red-500 text-white px-6 py-2 rounded-full font-bold">إغلاق</button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-[2.5rem]">
                  <h4 className="font-black text-blue-900 mb-4 flex items-center gap-2"><Clock size={18}/> سجل دخول جود</h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                    {visitLogs.map(log => (
                      <div key={log.id} className="bg-white p-3 rounded-xl text-[10px] flex justify-between items-center shadow-sm">
                        <span className="font-bold text-slate-600">{log.timestamp}</span>
                        <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-md flex items-center gap-1">
                          {log.device === "جوال" ? <Smartphone size={10}/> : <Monitor size={10}/>} {log.device}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-emerald-50 p-6 rounded-[2.5rem]">
                  <h4 className="font-black text-emerald-900 mb-4 flex items-center gap-2"><Award size={18}/> سجل نتائج الاختبارات</h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                    {testLogs.map(log => (
                      <div key={log.id} className="bg-white p-3 rounded-xl text-[10px] flex justify-between items-center shadow-sm border-r-4 border-emerald-400">
                        <span className="font-bold text-slate-800">{log.lesson}</span>
                        <span className="font-black text-emerald-600">{log.score}%</span>
                        <span className="text-slate-400">{log.timestamp.split(',')[0]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <form onSubmit={addSmartQuiz} className="bg-slate-50 p-6 rounded-[2.5rem] space-y-3">
                  <h4 className="font-black text-slate-800 text-sm border-b pb-2">إضافة سؤال MCQ سريع</h4>
                  <input name="lesson" placeholder="اسم الدرس" className="w-full p-3 rounded-xl border text-xs font-bold" required />
                  <textarea name="rawData" placeholder="السؤال | خيار1 | خيار2 | خيار3 | خيار4 | رقم الإجابة" 
                    className="w-full h-24 p-3 rounded-xl border text-[11px] leading-relaxed text-right" required dir="rtl" />
                  <p className="text-[9px] text-slate-400 font-bold italic text-center">السؤال | خيار1 | خيار2 | خيار3 | خيار4 | 1</p>
                  <button className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold">إضافة لبنك الأسئلة</button>
                </form>

                <div className="flex gap-4">
                  <button onClick={() => { if(window.confirm("حذف كل سجلات الزيارة؟")) visitLogs.forEach(l => deleteDoc(doc(db, 'visits', l.id))) }} className="flex-1 bg-red-50 text-red-500 py-3 rounded-2xl text-[10px] font-bold">تفريغ سجل الزيارات</button>
                  <button onClick={() => { if(window.confirm("حذف كل سجلات النتائج؟")) testLogs.forEach(l => deleteDoc(doc(db, 'test_results', l.id))) }} className="flex-1 bg-red-50 text-red-500 py-3 rounded-2xl text-[10px] font-bold">تفريغ سجل النتائج</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showLogin && !isAdmin && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-white p-8 rounded-[2.5rem] w-full max-w-sm text-center shadow-2xl">
            <h3 className="text-xl font-black mb-6">الرمز السري</h3>
            <input type="password" onChange={(e) => setPass(e.target.value)} className="w-full p-4 bg-slate-50 rounded-2xl mb-4 text-center font-bold border" />
            <button onClick={() => pass === "1234" ? setIsAdmin(true) : alert("خطأ!")} className="w-full bg-emerald-600 text-white py-3 rounded-2xl font-bold">دخول</button>
            <button onClick={() => setShowLogin(false)} className="mt-4 text-slate-400 text-sm">إلغاء</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
